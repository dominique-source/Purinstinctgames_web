# PürInstinct Games website package

Maquettes et assets pour modifier la page d’accueil de PürInstinctGames.com et créer la page dédiée Classroom Edition.

## Dépôt cible unique

https://github.com/dominique-source/Purinstinctgames_web.git

Ce package ne doit pas être utilisé dans `Purinstinct-official` ou dans un autre dépôt.

Avant toute modification, vérifier obligatoirement :

- `pwd`
- `git remote -v`
- `git branch --show-current`
- `git status --short`

Le remote `origin` doit correspondre à `dominique-source/Purinstinctgames_web`.

## Objectif

- Conserver `LOGIN`.
- Conserver `RECEVOIR MON LIEN D’ACCÈS`.
- Montrer plusieurs éditions PürInstinct Games.
- Rendre seulement Classroom Edition lumineuse et cliquable.
- Garder les autres éditions visibles, assombries et verrouillées.
- Créer une vraie page Classroom Edition.
- Préparer quatre emplacements vidéo et quatre emplacements photo.
- Ne pas générer de fausses photos d’élèves.

## Contenu

- `mockups/homepage-desktop-mockup.png`
- `mockups/classroom-edition-desktop-mockup.png`
- `assets/editions/` : quatre fonds d’éditions sans texte.
- `assets/classroom/` : fond hero et média sans texte.
- `brief/requirements-fr.md` : exigences fonctionnelles et éditoriales.
- `ASSET-MAP.md` : correspondance des fichiers.

## Direction visuelle

- Noir : `#05070A`
- Charbon : `#10151D`
- Blanc : `#F5F7FA`
- Argent : `#AAB4C0`
- Bleu électrique : `#0788FF`
- Bleu lumineux : `#25B7FF`

Les effets d’opacité, de désaturation, de verrouillage et de hover doivent être appliqués dans le code. Ne pas modifier les fichiers sources pour créer les états verrouillés.

