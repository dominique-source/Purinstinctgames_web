# Exigences PürInstinct Games

## Page d’accueil

Créer une section principale intitulée :

`CHOOSE YOUR PÜRINSTINCT GAMES EXPERIENCE`

Présenter plusieurs grandes zones appartenant au même univers sportif premium.

Éditions initiales :

1. `PÜRINSTINCT GAMES — CLASSROOM EDITION`
2. `PÜRINSTINCT GAMES — SCHOOL EDITION`
3. `PÜRINSTINCT GAMES — FESTIVAL EDITION`
4. `PÜRINSTINCT GAMES — IRL / LARGE SCALE EDITION`

Le système doit permettre d’ajouter d’autres éditions à partir d’une structure de données.

Classroom Edition est la seule édition active. Elle doit être lumineuse, nette, fortement contrastée et clairement cliquable. Utiliser `AVAILABLE NOW` et un CTA clair.

Toutes les autres éditions restent visibles afin de montrer l’ampleur future de l’univers. Elles doivent être assombries, désaturées, non cliquables et identifiées par `COMING SOON` ou `IN DEVELOPMENT`.

Conserver dans le header :

- `LOGIN`
- `RECEVOIR MON LIEN D’ACCÈS`

Les icônes des éditions doivent rester visibles et lisibles pour tout le monde. Seule l’icône Classroom Edition est lumineuse et active.

## Page Classroom Edition

Créer une route dédiée à Classroom Edition.

Hero :

`PÜRINSTINCT GAMES`

`CLASSROOM EDITION`

`6 CLASSES. 5 GAMES. 1 PÜRINSTINCT GAMES EXPERIENCE.`

Le hero doit être sportif, moderne, compétitif et immersif. Aucun style scolaire enfantin.

## Progression des six classes

- `CLASS 01 — PÜRINSTINCT`
- `CLASS 02 — PÜRINSTINCT`
- `CLASS 03 — PÜRINSTINCT + GAME 01`
- `CLASS 04 — PÜRINSTINCT + GAMES 02–03`
- `CLASS 05 — PÜRINSTINCT + GAMES 04–05`
- `CLASS 06 — PÜRINSTINCT GAMES`

La classe 06 représente le point culminant.

## Media showcase

Créer quatre emplacements vidéo remplaçables facilement :

1. Vidéo horizontale 16:9 : `HORIZONTAL VIDEO — EXPERIENCE / CLASS EXAMPLE`
2. Vidéo horizontale 16:9 : `HORIZONTAL VIDEO — GAMEPLAY / HOW IT WORKS`
3. Vidéo promotionnelle 16:9, plus spectaculaire : `PÜRINSTINCT GAMES — PROMO VIDEO`
4. Vidéo verticale 9:16 : `VERTICAL VIDEO — SOCIAL / REAL CLASS EXPERIENCE`

Chaque composant vidéo doit prévoir :

- thumbnail;
- bouton Play;
- plein écran lorsque la vraie vidéo sera intégrée;
- remplacement simple par URL ou fichier;
- ratio responsive;
- titre accessible;
- aucune lecture automatique avec son.

## Placeholders photo

Créer quatre emplacements propres et remplaçables :

- `CLASSROOM PHOTO`
- `PÜRINSTINCT GAMEPLAY PHOTO`
- `STUDENT EXPERIENCE PHOTO`
- `PÜRINSTINCT GAMES FINAL DAY`

Ne pas générer de fausses photos d’élèves. Utiliser des placeholders visuels propres, cohérents avec la marque.

## Architecture

Créer les éditions à partir d’une structure de données réutilisable. Prévoir au minimum :

- identifiant;
- titre;
- statut;
- image;
- route;
- actif ou verrouillé;
- label d’état;
- texte alternatif.

Créer aussi la progression des six classes à partir d’une structure de données.

## Responsive

Sur desktop, privilégier de grandes zones éditoriales et un hover uniquement sur Classroom Edition.

Sur mobile :

- Classroom Edition apparaît immédiatement comme disponible;
- les formats verrouillés restent visibles;
- la vidéo verticale devient centrale;
- les vidéos horizontales gardent leur ratio;
- les textes ne débordent pas;
- aucune image ne doit être étirée.

## Accessibilité

- navigation clavier;
- focus visible;
- contrastes suffisants;
- alt text;
- états verrouillés compréhensibles sans dépendre uniquement de la couleur;
- contrôles vidéo accessibles;
- respect de `prefers-reduced-motion`.

## Contraintes

- Ne pas reconstruire tout le site.
- Réutiliser le login, le système d’accès, les composants, couleurs et typographies existants.
- Ne pas modifier le fonctionnement de `RECEVOIR MON LIEN D’ACCÈS`.
- Ne pas rendre les éditions futures cliquables.
- Ne pas créer de liens vides ou de routes inventées pour les formats verrouillés.
- Ne pas utiliser un design SaaS avec de petites cartes blanches.
- Ne pas ajouter de fausses photos d’élèves.
- Ne pas supprimer les sections existantes sans raison.

