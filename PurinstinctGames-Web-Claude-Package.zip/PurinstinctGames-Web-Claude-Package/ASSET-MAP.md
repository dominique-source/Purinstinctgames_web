# Asset map

| Fichier | Usage |
| --- | --- |
| `mockups/homepage-desktop-mockup.png` | Référence visuelle de la nouvelle page d’accueil |
| `mockups/classroom-edition-desktop-mockup.png` | Référence visuelle de la page Classroom Edition |
| `assets/editions/classroom-edition-active.png` | Carte active Classroom Edition |
| `assets/editions/school-edition.png` | Carte verrouillée School Edition |
| `assets/editions/festival-edition.png` | Carte verrouillée Festival Edition |
| `assets/editions/irl-large-scale-edition.png` | Carte verrouillée IRL / Large Scale Edition |
| `assets/classroom/classroom-hero-media-background.png` | Hero Classroom et fonds temporaires des placeholders média |

## États attendus

### Classroom Edition

- 100 % d’opacité
- couleur complète
- bordure ou glow bleu
- lien actif
- hover léger
- clavier et focus accessibles
- label `AVAILABLE NOW`

### Éditions futures

- non cliquables
- `aria-disabled="true"` si un contrôle est utilisé
- pas de faux lien vide
- opacité et saturation réduites en CSS
- overlay sombre
- icône de verrouillage nette et lisible
- aucun hover donnant l’impression que la carte est active
- labels `COMING SOON` ou `IN DEVELOPMENT`

